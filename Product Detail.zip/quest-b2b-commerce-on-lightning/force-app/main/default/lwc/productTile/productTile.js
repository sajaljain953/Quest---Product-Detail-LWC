import { api, LightningElement, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getProductRecs from '@salesforce/apex/ProductTile.getProductRecs';
import getProdId from '@salesforce/apex/ProductTile.getProdId';
import { addItemToCart } from 'commerce/cartApi';
import addWishListItem from '@salesforce/apex/AddWishList.addWishListItem';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import USER_ID from '@salesforce/user/Id';
import ACCOUNT_ID from '@salesforce/schema/User.AccountId';
import { getRecord, getFieldValue } from "lightning/uiRecordApi";
import getSiteBaseUrl from '@salesforce/apex/AddWishList.getSiteBaseUrl';
import WebstoreId from '@salesforce/label/c.WebstoreId';

export default class FeaturedProducts1 extends NavigationMixin(LightningElement) {
    @track products = [];
    @track displayedProducts = [];
    @track carouselIndicators = [];
    @track currentPage = 0;
    @track itemsPerPage = 10;
    @track productCounters = {}; // Store quantity for each product
    @track accountId;
    @track storeId;
    siteBaseUrl;
    @api pricebookID;
    categoryId;

    @wire(getSiteBaseUrl)
    wiredSiteBaseUrl({ error, data }) {
        if (data) {
            this.siteBaseUrl = data;
        } else if (error) {
            console.error('Error fetching site base URL:', error);
        }
    }

    @wire(getRecord, { recordId: USER_ID, fields: [ACCOUNT_ID] })
    user({ data, error }) {
        if (data) {
            this.accountId = getFieldValue(data, ACCOUNT_ID);
        } else if (error) {
            console.error('Error fetching user data:', error);
        }
    }

    @wire(CurrentPageReference)
    getPageReference(pageReference) {
        if (pageReference?.attributes?.objectApiName === 'ProductCategory') {
            this.categoryId = pageReference.attributes.recordId;
            if (this.categoryId) {
                this.fetchProductsByCategory();
            } else {
                this.fetchProducts();
            }
        }
    }

    connectedCallback() {
        this.storeId = WebstoreId;
    }

    fetchProducts() {
        getProductRecs()
            .then((data) => {
                this.products = data.map(product => ({
                    ...product,
                    isWishlistItem: false,
                    formattedUnitPrice: this.formatPrice(product.UnitPrice)
                }));
                this.setupCarousel();
            })
            .catch((error) => {
                console.error('Error fetching products:', error);
            });
    }

    fetchProductsByCategory() {
        getProdId({ catId: this.categoryId })
            .then((data) => {
                if (data && data.length > 0) {
                    this.products = data.map((product) => ({
                        ...product,
                        isWishlistItem: false,
                        formattedUnitPrice: this.formatPrice(product.UnitPrice)
                    }));
                    this.setupCarousel();
                } else {
                    console.error('No products returned from Apex.');
                }
            })
            .catch((error) => {
                console.error('Error fetching products by category:', error);
            });
    }

    formatPrice(price) {
        return Number(price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    setupCarousel() {
        this.currentPage = 0;
        this.updateDisplayedProducts();
        this.carouselIndicators = Array(Math.ceil(this.products.length / this.itemsPerPage)).fill().map((_, index) => {
            return {
                index,
                class: `splide__pagination__page ${index === this.currentPage ? 'is-active' : ''}`
            };
        });
    }

    updateDisplayedProducts() {
        const startIndex = this.currentPage * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        this.displayedProducts = this.products.slice(startIndex, endIndex);
    }

    handlePrevious() {
        if (this.currentPage > 0) {
            this.currentPage--;
            this.updateDisplayedProducts();
            this.updateIndicatorClasses();
        }
    }

    handleNext() {
        if (this.currentPage < this.carouselIndicators.length - 1) {
            this.currentPage++;
            this.updateDisplayedProducts();
            this.updateIndicatorClasses();
        }
    }

    handleIndicatorClick(event) {
        this.currentPage = parseInt(event.target.dataset.index, 10);
        this.updateDisplayedProducts();
        this.updateIndicatorClasses();
    }

    updateIndicatorClasses() {
        this.carouselIndicators = this.carouselIndicators.map((indicator) => ({
            ...indicator,
            class: `splide__pagination__page ${indicator.index === this.currentPage ? 'is-active' : ''}`
        }));
    }

    handleAddToWishlist(event) {
        const productId = event.target.dataset.id;
        if (!this.accountId || !this.storeId || !productId) {
            this.showToast('Error', 'Missing account, store, or product information', 'error');
            return;
        }

        addWishListItem({ accountId: this.accountId, storeId: this.storeId, productIds: [productId] })
            .then(() => {
                
                this.showToast('Success', 'Product added to wishlist', 'success');
                this.updateWishlistIcon(productId, true);
            })
            .catch((error) => {
                console.error('Error adding to wishlist:', error);
                this.showToast('Error', 'Failed to add product to wishlist', 'error');
            });
    }

    updateWishlistIcon(productId, isAdded) {
        this.products = this.products.map((product) =>
            product.Id === productId
                ? { ...product, isWishlistItem: isAdded,
                    wishlisticonClass: isAdded ? 'wishlist-icon wishlist-added' : 'wishlist-icon'
                 }
                : product
        );
        this.updateDisplayedProducts();
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title,
                message,
                variant,
                mode: 'dismissable'
            })
        );
    }
}