import { LightningElement, api, track, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getProductDetails from '@salesforce/apex/productDetail.getProductDetails'; // Apex method to fetch product details
import getProductSellingModel from '@salesforce/apex/productDetail.getProductSellingModel';
import getProductDiscountList from '@salesforce/apex/productDetail.getProductRecsForDiscount';
import getVariationProduct from '@salesforce/apex/productDetail.getVariationProduct';
import { addItemToCart } from 'commerce/cartApi';
export default class ProductDetailTile extends LightningElement {

    @track product = null; // Main product details
    @track variations = []; // List of product variations
    @track selectedVariation = null; // Selected variation (if applicable)
    @track quantity = 1; // Default quantity
    @track dropdownVisible = {}; // Object to track which variation dropdowns are visible
    @track productDiscountList = [];

    @wire(CurrentPageReference)
    getPageReference(pageReference) {
        if (pageReference) {
            const urlPath = pageReference.attributes.recordId; // Fetch product ID from URL
            if (urlPath) {
                this.fetchProductDetails(urlPath);
                this.fetchProductVariations(urlPath);
            }
        }
    }

    @wire(getProductDiscountList)
    wiredProductDiscountList({ error, data }) {
        if (data) {
            this.productDiscountList = data.map(product => ({
                ...product,
                formattedFinalPrice: product.Final_price__c
                    ? Number(product.Final_price__c).toLocaleString('en-US', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                      })
                    : null,
            }));
        } else if (error) {
            console.error('Error retrieving product discount list:', error);
        }
    }

    connectedCallback(){    
        this.variations.forEach(variation => {
            variation.isDropdownVisible = false; // Start with all variations hidden
            variation.iconName = 'utility:chevrondown'; // Accordion up (collapsed) by default
        });
    }
   
            fetchProductDetails(productId) {
                getProductDetails({ productId })
                    .then((data) => {
                        if (data) {
                            const discountedProduct = this.productDiscountList.find(
                                (product) => product.Id === data.Product2Id
                            );
                            this.product = {
                                ...data,
                                formattedUnitPrice: Number(data.UnitPrice).toLocaleString('en-US', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2,
                                }),
                                name: data.Product2.Name,
                                description: data.Product2.Description,
                                discountedPrice: discountedProduct
                                    ? discountedProduct.formattedFinalPrice
                                    : null, // Add discounted price if available
                            };
                            console.log('Product with discounted price:', this.product);
                            this.fetchProductSellingModel(productId);
                        }
                    })
                    .catch((error) => {
                        console.error('Error fetching product details:', error);
                        this.product = null; // Clear product data if error
                    });
            }
    // Fetch selling model details
    fetchProductSellingModel(productId) {
        getProductSellingModel({ productId })
            .then((data) => {
                if (data) {
                    this.product = {
                        ...this.product,
                        sellingModel: data.PricingTerm
                            ? {
                                  name: data.Name,
                                  pricingTerm: data.PricingTerm,
                                  pricingTermUnit: data.PricingTermUnit,
                                  sellingModelType: data.SellingModelType,
                              }
                            : null, // Set to null if no selling model data
                    };
                }
            })
            .catch((error) => {
                console.error('Error fetching product selling model:', error);
            });
    }
    // Working code 
    // fetchProductVariations(productId) {
    //     getVariationProduct({ productId })
    //         .then((data) => {
    //             if (data && data.length > 0) {
    //                 this.variations = data.map((variation) => ({
    //                     id: variation.ProductId,
    //                     attributeId: variation.AttributeId,
    //                     attributeName: variation.AttributeName,
    //                     softwareVersion: variation.SoftwareVersion,
    //                     name: variation.ProductName,
    //                     description: variation.ProductDescription,
    //                     sku: variation.ProductSKU,
    //                     price: variation.UnitPrice
    //                         ? Number(variation.UnitPrice).toLocaleString('en-US', {
    //                               minimumFractionDigits: 2,
    //                               maximumFractionDigits: 2,
    //                           })
    //                         : null,
    //                     discountedPrice: variation.DiscountedPrice
    //                         ? Number(variation.DiscountedPrice).toLocaleString('en-US', {
    //                               minimumFractionDigits: 2,
    //                               maximumFractionDigits: 2,
    //                           })
    //                         : null,
    //                     variantParentId: variation.VariantParentId,
    //                     variantParentName: variation.VariantParentName,
    //                     sellingModel: variation.SellingModelName
    //                         ? {
    //                               name: variation.SellingModelName,
    //                               pricingTerm: variation.PricingTerm,
    //                               pricingTermUnit: variation.PricingTermUnit,
    //                               sellingModelType: variation.SellingModelType,
    //                           }
    //                         : null, // Set to null if no selling model data
    //                     isDropdownVisible: false, // For accordion functionality
    //                     iconName: 'utility:chevrondown', // Accordion up (collapsed) by default
    //                 }));
     
    //                 // Clear the parent product if variations exist
    //                 if (this.variations.length > 0) {
    //                     this.product = null;
    //                 }
    //             }
    //         })
    //         .catch((error) => {
    //             console.error('Error fetching product variations:', error);
    //         });
    // }

    // Working but showing Undefined
    fetchProductVariations(productId) {
        getVariationProduct({ productId })
            .then((data) => {
                // Log the fetched data to check if the discounted price is included
                console.log('Fetched product variations data:', data);
                
                if (data && data.length > 0) {
                    this.variations = data.map((variation) => {
                        // Log the details of each variation
                        console.log('Processing variation:', variation);
    
                        const variationDetails = {
                            id: variation.ProductId,
                            attributeId: variation.AttributeId,
                            attributeName: variation.AttributeName,
                            softwareVersion: variation.SoftwareVersion,
                            name: variation.ProductName,
                            description: variation.ProductDescription,
                            sku: variation.ProductSKU,
                            variantParentId: variation.VariantParentId,
                            variantParentName: variation.VariantParentName,
                            sellingModel: variation.SellingModelName
                                ? {
                                      name: variation.SellingModelName,
                                      pricingTerm: variation.PricingTerm,
                                      pricingTermUnit: variation.PricingTermUnit,
                                      sellingModelType: variation.SellingModelType,
                                  }
                                : null, // Set to null if no selling model data
                            isDropdownVisible: false, // For accordion functionality
                            iconName: 'utility:chevrondown', // Accordion up (collapsed) by default
                        };
    
                        // Format the price fields
                        variationDetails.price = variation.UnitPrice
                            ? Number(variation.UnitPrice).toLocaleString('en-US', {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2,
                              })
                            : 'No Price Available';
    
                        // Log if the discounted price exists
                       // console.log('Discounted price for variation', variation.id, variation.DiscountedPrice);
                       console.log(`Discounted price for variation ${variation.ProductId || 'N/A'}: `,
                                    variation.DiscountedPrice);
    
                       // Check and apply discounted price if available
                        if (variation.DiscountedPrice) {
                            variationDetails.discountedPrice = Number(variation.DiscountedPrice).toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                            });
                        }
                        console.log('Variation Details: ',variationDetails );
                        return variationDetails;
                    });
    
                    // Log the variations to check after mapping
                    console.log('Mapped variations:', this.variations);
    
                    // Clear the parent product if variations exist
                    if (this.variations.length > 0) {
                        this.product = null;
                    }
                }
            })
            .catch((error) => {
                console.error('Error fetching product variations:', error);
            });
    }

    // Handle Quantity Change for main product or variations
    handleQuantityChange(event) {
        const variationId = event.target.dataset.id;
        const newQuantity = event.target.value;
        if (variationId) {
            const selectedVariation = this.variations.find((variation) => variation.id === variationId);
            if (selectedVariation) {
                selectedVariation.quantity = newQuantity;
            }
        } else {
            this.quantity = newQuantity;
        }
    }
    
    toggleDropdown(event) {
        const variationId = event.target.dataset.id;
        const variation = this.variations.find(v => v.id === variationId);
        if (variation) {
            // Toggle the visibility of the dropdown content
            variation.isDropdownVisible = !variation.isDropdownVisible;
            // Set the appropriate icon based on the visibility state
            variation.iconName = variation.isDropdownVisible ? 'utility:chevronup' : 'utility:chevrondown';
        }
    }

    // Handle Add to Cart functionality
    handleAddToCart(event) {
        const productId = event.target.dataset.id;
        const quantity = event.target.dataset.quantity || this.quantity;
        addItemToCart(productId, quantity)
            .then(() => {
                this.showToast('Success', 'Product added to cart!', 'success');
            })
            .catch((error) => {
                console.error('Error adding item to cart:', error);
                this.showToast('Error', 'Failed to add product to cart.', 'error');
            });
    }
    // Show toast notifications
    showToast(title, message, variant) {
        const evt = new ShowToastEvent({
            title,
            message,
            variant,
        });
        this.dispatchEvent(evt);
    }
}
 
 