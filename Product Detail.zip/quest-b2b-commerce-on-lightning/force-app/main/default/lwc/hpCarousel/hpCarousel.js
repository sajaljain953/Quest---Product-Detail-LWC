import { LightningElement, api, track } from 'lwc';

export default class HpCarousel extends LightningElement {
    @track slides = [
        {
            id: 0,
            imgUrl: 'https://insightsoftware.com/wp-content/uploads/2022/11/22-11-WBR-FinancialReportingTrends2023-Website.png',
            link: 'https://example.com/page1' // Replace with actual link
        },
        {
            id: 1,
            imgUrl: 'https://insightsoftware.com/wp-content/uploads/2019/09/24-08-WEB-WP-howtocomparereportingbisolutions-Website.png',
            link: 'https://example.com/page2' // Replace with actual link
        }
    ];
    @track currentSlide = 0;
    autoSlideInterval;

    // Properties to control the slider functionalities
    @api isArrowSlider = false;
    @api useDotSlider = false;
    @api autoSlideEnabled = false;
    @api useDotWithAutoSlide = false;
    @api overlayColor = '#000000';
    @api overlayOpacity = 0.5;
   

    // Computed property to determine if dots should be shown
    get showDots() {
        return this.useDotSlider || this.useDotWithAutoSlide;
    }

    // Style for slides container based on the current slide index
    get slidesStyle() {
        const slideWidth = 100; // percentage width for each slide
        return `transform: translateX(-${this.currentSlide * slideWidth}%);`;
    }
    get overlayStyle() {
        return `background-color: ${this.overlayColor}; opacity: ${this.overlayOpacity};`;
    }
 
    // Update dot classes based on the current slide
    updateDotClass() {
        if (this.useDotSlider || this.useDotWithAutoSlide) {
            this.slides = this.slides.map((slide, index) => ({
                ...slide,
                dotClass: index === this.currentSlide ? 'dot active' : 'dot'
            }));
        }
    }
    handleOverlayColorChange(event) {
        this.overlayColor = event.target.value;
    }

    // Method to initialize the auto-slide functionality
    startAutoSlide() {
        if (this.autoSlideEnabled || this.useDotWithAutoSlide) {
            this.autoSlideInterval = setInterval(() => {
                this.nextSlide();
            }, 3000); // Change slide every 3 seconds
        } else {
            this.stopAutoSlide();
        }
    }

    // Stop auto-slide functionality
    stopAutoSlide() {
        if (this.autoSlideInterval) {
            clearInterval(this.autoSlideInterval);
            this.autoSlideInterval = null;
        }
    }

    // Navigate to the previous slide
    prevSlide() {
        this.currentSlide = (this.currentSlide === 0) ? this.slides.length - 1 : this.currentSlide - 1;
        this.updateDotClass();
    }

    // Navigate to the next slide
    nextSlide() {
        this.currentSlide = (this.currentSlide === this.slides.length - 1) ? 0 : this.currentSlide + 1;
        this.updateDotClass();
    }
    
    // Change the slide based on dot click
    changeSlide(event) {
        const targetSlide = parseInt(event.target.getAttribute('data-slide'), 10);
        this.currentSlide = targetSlide;
        this.updateDotClass();
    }

    // Lifecycle hook to initialize the component
    connectedCallback() {
        this.updateDotClass();
        this.startAutoSlide();
    }

    disconnectedCallback() {
        this.stopAutoSlide();
    }
}