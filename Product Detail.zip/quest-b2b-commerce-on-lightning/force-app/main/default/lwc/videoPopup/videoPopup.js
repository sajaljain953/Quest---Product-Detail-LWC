import { LightningElement, api } from 'lwc';

export default class VideoPopup extends LightningElement {
    // Public property to accept the thumbnail image URL
    @api imageUrl;

    // Private property to handle modal state
    isModalOpen = false;

    // The video URL you want to play in the modal
    videoUrl = 'https://youtu.be/Xnr0HhFvgHE?si=t0zjX1lnAbfNj8__'; // Example URL, replace with your video URL

    // Method to open the modal
    handleThumbnailClick() {
        this.isModalOpen = true;
    }

    // Method to close the modal
    handleCloseModal() {
        this.isModalOpen = false;
    }
}